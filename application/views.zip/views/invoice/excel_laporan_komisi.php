<?php
$file = "LAPORAN_KOMISI_ORCHARD_".date('d_M_y',strtotime($tgl1))."_sd_".date('d_M_y',strtotime($tgl2)).".xls";
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=$file");
?>
<table class="table" border="1">
	<thead>
		<th colspan="5">Laporan Komisi <?= date('d_M_y',strtotime($tgl1)) ?> -  <?= date('d_M_y',strtotime($tgl2)) ?></th>	
	</thead>
	<thead class="thead-light">
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Komisi Servie</th>
                <th>Komisi Penjualan</th>
                <th>Total Komisi</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $total_app = 0;
        $total_penjualan = 0;
        $total = 0;
        ?>
        <?php foreach ($komisi as $key => $value): ?>
        <?php 
            $names = ['T1', 'T2', 'T3','T4','T5','T6','T7','T8','T9','T10'];
            if(in_array($value->nm_kry,$names)){
                continue;
            } 
        ?>
        
        <?php 
            $total_app += $value->total_app;
            $total_penjualan += $value->total_produk;
            $total += $value->total_app;
            $total += $value->total_produk;     
        ?>
			<tr>
				<td><?= $key+1 ?></td>
                <td><?= $value->nm_kry ?></td>
                <td style="text-align: right; mso-number-format:\@;"><?= number_format($value->total_app) ?></td>
                <td style="text-align: right; mso-number-format:\@;"><?= number_format($value->total_produk) ?></td>
				<td style="text-align: right; mso-number-format:\@;"><?= number_format($value->total_produk + $value->total_app) ?></td>
			</tr>
		<?php endforeach ?>
        </tbody>
        <tfoot class="bg-secondary text-light">
            <tr>
                <td colspan=2>Total</td>
                <td style="text-align: right; mso-number-format:\@;"><?= number_format($total_app,0) ?></td>
                <td style="text-align: right; mso-number-format:\@;"><?= number_format($total_penjualan,0) ?></td>
                <td style="text-align: right; mso-number-format:\@;"><?= number_format($total,0) ?></td>
            </tr>
        </tfoot>
</table>