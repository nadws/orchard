<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Komisi</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>

<div class="container">
<div class="row">
    <div class="col-6">
        <h3>Laporan Komisi</h3>
    </div>
    <div class="col-6">
       <strong><p class="float-right">Periode : <?= date('d M Y', strtotime($tgl1)) ?> - <?= date('d M Y', strtotime($tgl2)) ?></p></strong>
        
    </div>
    <div class="col-12">
    <hr>
    <table class="table">
        <thead class="thead-light">
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Komisi Servie</th>
                <th>Komisi Penjualan</th>
                <th>Total Komisi</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $total_app = 0;
        $total_penjualan = 0;
        $total = 0;
        ?>
        <?php foreach ($komisi as $key => $value): ?>
        <?php 
            $names = ['T1', 'T2', 'T3','T4','T5','T6','T7','T8','T9','T10'];
            if(in_array($value->nm_kry,$names)){
                continue;
            } 
        ?>
        
        <?php 
            $total_app += $value->total_app;
            $total_penjualan += $value->total_produk;
            $total += $value->total_app;
            $total += $value->total_produk;     
        ?>
			<tr>
				<td><?= $key+1 ?></td>
                <td><?= $value->nm_kry ?></td>
                <td>Rp. <?= number_format($value->total_app) ?></td>
                <td>Rp. <?= number_format($value->total_produk) ?></td>
				<td>Rp. <?= number_format($value->total_produk + $value->total_app) ?></td>
			</tr>
		<?php endforeach ?>
        </tbody>
        <tfoot class="bg-secondary text-light">
            <tr>
                <td colspan=2>Total</td>
                <td>RP. <?= number_format($total_app,0) ?></td>
                <td>RP. <?= number_format($total_penjualan,0) ?></td>
                <td>RP. <?= number_format($total,0) ?></td>
            </tr>
        </tfoot>
    </table>
    
    </div>
</div>
</div>
    

</body>
</html>