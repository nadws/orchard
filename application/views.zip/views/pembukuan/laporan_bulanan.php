<?php $this->load->view('tema/Header', $title); ?>

<script src="<?= base_url('css_maruti/'); ?>js/jquery.min.js"></script> 
<script src="<?php echo base_url('css_maruti/'); ?>assets/ajax.js"></script>

<style type="text/css">

.modal .modal-dialog-aside{
	width: 350px;
	max-width:80%; height: 500px; margin:0;
	transform: translate(0); transition: transform .2s;
}


.modal .modal-dialog-aside .modal-content{  height: inherit; border:0; border-radius: 0;}
.modal .modal-dialog-aside .modal-content .modal-body{ overflow-y: auto }
.modal.fixed-left .modal-dialog-aside{ margin-left:auto;  transform: translateX(100%); }
.modal.fixed-right .modal-dialog-aside{ margin-right:auto; transform: translateX(-100%); }

.modal.show .modal-dialog-aside{ transform: translateX(0);  }

.th{            
            top: 54px;            
        }

</style>

<!-- ======================================================== conten ======================================================= -->
<!-- Content Wrapper. Contains page content -->
<!-- <div class="content-wrapper"> -->
	
	<div class="content-header">
		<div class="container">

			<div class="row mb-2">
				<!-- <div class="col-sm-12">
					<h1 class="m-0 text-dark">Jurnal</h1>
				</div> -->
				<div class="col-sm-6">
					<?php if ($this->session->userdata('edit_hapus')=='1'): ?>
						<!-- <button data-toggle="modal" data-target="#modal-detail" class="btn btn-success"><i class="fas fa-download"></i> Detail</button> -->
						<!--<button data-toggle="modal" data-target="#modal-view" class="btn btn-success"><i class="fas fa-eye"></i> View</button>-->
						<!--<button data-toggle="modal" data-target="#modal-summary" class="btn btn-success"><i class="fas fa-print"></i> Summary</button>-->
						<!-- <button data-toggle="modal" data-target="#modal-delete" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button> -->
					<?php endif ?>
				</div>
				<!-- <div class="col-5 mt-2">
					<a href="<?= base_url('match/order'); ?>" class="btn btn-warning">Kembali</a>
				</div> -->
			</div>
		</div>
		<div class="row justify-content-center">
			<div class="col-md-12">
				
			</div>
			<div class="col-12">
      <?= $this->session->flashdata('message'); ?>

      <!-- <?php 
      $bulan = ['bulan','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember']; 
      $bulan1 = (int)$month;      
      ?> -->
      <?php if($this->session->userdata('id_role')=='1' || $this->session->userdata('id_role')=='4'): ?>
				<div class="card">
                    <!-- <div class="card-header">
                       <button type="button" class="btn btn-sm btn-outline-secondary float-right ml-2" data-toggle="modal" data-target="#add-laporan"><i class="fa fa-plus"></i> Add Laporan</button>
                       
                      </div> -->                        
                      <div class="card-header">
                       <h4 class="float-left">Laporan Pemasukan</h4>                       
                       
                      </div>    
                    <div class="card-body">
                       

                       <?php 
                       $t_pemasukan = 0;
                       ?>
                       <table class="table table-sm table-bordered">

                            <thead>
                            <tr>
                                <th>Akun</th>
                                <?php foreach ($periode as $key => $value): ?>
                                    <?php $bulan=  date('M-Y', strtotime($value->tgl)) ?>
                                        <th><?= $bulan ?></th>
                                <?php endforeach ?>   
                            </tr> 
                            </thead>
                            <tbody>
                            <?php foreach($akun_pendapatan as $ap): ?>
                            <tr>
                            <td><?= $ap->nm_akun ?></td>
                            <?php foreach($periode as $pd): ?>
                                    <?php 
                                        $month = date('m' , strtotime($pd->tgl));
                                        $year = date('Y' , strtotime($pd->tgl));
                                        $jml = $this->db->select_sum('debit')->select_sum('kredit')->join('tb_akun','tb_jurnal.id_akun = tb_akun.id_akun')->get_where('tb_jurnal',[
                                            'tb_akun.id_akun' => $ap->id_akun,
                                            'tb_jurnal.id_buku !=' => 3,
                                            'MONTH(tgl)' => $month,
                                            'YEAR(tgl)' => $year
                                        ])->row();
                                        // $ket = $this->db->get_where(" tb_absen where nm_karyawan = '$kry->nm_kry' and tgl BETWEEN '$dt_c' AND '$dt_a' order by tgl ASC, nm_karyawan ")->result();    
                                    $debit = $jml->debit;
                                    $kredit = $jml->kredit;

                                    $jumlah_p = $kredit - $debit;

                                    if(!$jumlah_p){
                                        $jumlah_p = 0;
                                    }

                                    $t_pemasukan += $jumlah_p;

                                    ?>
                                    <td><?= number_format($jumlah_p,0) ?></td>
                                        
                                    <?php endforeach; ?>      
                            </tr>
                            <?php endforeach ?>

                            <tr>
                            <td><strong>Total</strong></td>

                            <?php foreach($periode as $pd): ?>

                            <?php
                             $month = date('m' , strtotime($pd->tgl));
                             $year = date('Y' , strtotime($pd->tgl));
                            $ttl = $this->db->select_sum('debit')->select_sum('kredit')->join('tb_akun','tb_jurnal.id_akun = tb_akun.id_akun')->get_where('tb_jurnal',[
                                            'tb_jurnal.id_buku' => 1,
                                            'tb_akun.pendapatan' => 'Y',
                                            'MONTH(tgl)' => $month,
                                            'YEAR(tgl)' => $year
                                        ])->row(); ?>                          
                                    <td><strong><?= number_format($ttl->kredit - $ttl->debit,0) ?></strong></td>

                            <?php endforeach; ?>        

                            </tr>        

                            </tbody>

                            </table>                              

                    </div>
					
				</div>

        <?php endif; ?>

        <?php if($this->session->userdata('id_role')=='1' || $this->session->userdata('id_role')=='2'): ?>                      
        <?php 
          $t_pengeluaran = 0;
          ?>
        <div class="card">

          <div class="card-header">
                       <h4 class="float-left">Laporan Pengeluaran</h4>                       
                       
                      </div>    
                    <div class="card-body">
                      
                       <table class="table table-sm table-bordered">

                            <thead>
                            <tr>
                                <th>Akun</th>
                                <?php foreach ($periode as $key => $value): ?>
                                    <?php $bulan=  date('M-Y', strtotime($value->tgl)) ?>
                                        <th><?= $bulan ?></th>
                                <?php endforeach ?>   
                            </tr> 
                            </thead>
                            <tbody>
                            <?php foreach($akun_pengeluaran as $ap): ?>
                            <tr>
                            <td><?= $ap->nm_akun ?></td>
                            <?php foreach($periode as $pd): ?>
                                    <?php 
                                        $month = date('m' , strtotime($pd->tgl));
                                        $year = date('Y' , strtotime($pd->tgl));
                                        $jml = $this->db->select_sum('debit')->select_sum('kredit')->join('tb_akun','tb_jurnal.id_akun = tb_akun.id_akun')->get_where('tb_jurnal',[
                                            'tb_akun.id_akun' => $ap->id_akun,
                                            'tb_jurnal.id_buku' => 3,
                                            'MONTH(tgl)' => $month,
                                            'YEAR(tgl)' => $year
                                        ])->row();
                                        // $ket = $this->db->get_where(" tb_absen where nm_karyawan = '$kry->nm_kry' and tgl BETWEEN '$dt_c' AND '$dt_a' order by tgl ASC, nm_karyawan ")->result();    
                                    $debit = $jml->debit;
                                    $kredit = $jml->kredit;

                                    $jumlah_p = $debit - $kredit;

                                    if(!$jumlah_p){
                                        $jumlah_p = 0;
                                    }

                                    $t_pengeluaran += $jumlah_p

                                    ?>
                                    <td><?= number_format($jumlah_p,0) ?></td>
                                        
                                    <?php endforeach; ?>      
                            </tr>
                            <?php endforeach ?>
                            <tr>
                            <td><strong>Total</strong></td>

                            <?php foreach($periode as $pd): ?>

                            <?php
                             $month = date('m' , strtotime($pd->tgl));
                             $year = date('Y' , strtotime($pd->tgl));
                            $ttl = $this->db->select_sum('debit')->select_sum('kredit')->join('tb_akun','tb_jurnal.id_akun = tb_akun.id_akun')->get_where('tb_jurnal',[
                                            'tb_jurnal.id_buku' => 3,
                                            'tb_akun.pengeluaran' => 'Y',
                                            'MONTH(tgl)' => $month,
                                            'YEAR(tgl)' => $year
                                        ])->row(); ?>                          
                                    <td><strong><?= number_format($ttl->debit - $ttl->kredit,0) ?></strong></td>

                            <?php endforeach; ?>        

                            </tr>
                            </tbody>

                            </table>
                      </div> 

        </div>
        <?php endif; ?>



			</div>
			
			
		</div>
	</div>

   
<!-- Modal add -->
<form action="<?= base_url('match/add_laporan_bulanan') ?>" method="POST">
<div class="modal fade" id="add-laporan" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background: #FFA07A;">
        <h5 class="modal-title" id="exampleModalLabel">Add data laporan bulanan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <div class="row">

        <div class="col-sm-12 col-md-12">
                  <div class="form-group">
                      <label for="list_kategori">Akun</label>
                      <select name="month" class="form-control" required="">                              
                          <option value="01">Januari</option>
                          <option value="02">Februari</option>
                          <option value="03">Maret</option>
                          <option value="04">April</option>
                          <option value="05">Mei</option>
                          <option value="06">Juni</option>
                          <option value="07">Juli</option>
                          <option value="08">Agustus</option>
                          <option value="09">September</option>
                          <option value="10">Oktober</option>
                          <option value="11">November</option>
                          <option value="12">Desember</option>                 
                      </select>
                  </div>
              </div>

              <div class="col-sm-12 col-md-12">
                  <div class="form-group">
                      <label for="list_kategori">Tahun</label>
                      <select name="year" class="form-control select" required="">
                          <?php foreach($tahun as $t): ?>                                
                            <?php  $tanggal = $t->tgl;
                            $explodetgl=explode('-', $tanggal); ?>
                          <option value="<?=$explodetgl[0];?>"><?=$explodetgl[0];?></option>
                          <?php endforeach; ?>
                        </select>  
                  </div>
              </div>

      </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </div>
  </div>
</div>
</form>


  





<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/solid.css" integrity="sha384-wnAC7ln+XN0UKdcPvJvtqIH3jOjs9pnKnq9qX68ImXvOGz2JuFoEiCjT8jyZQX2z" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/fontawesome.css" integrity="sha384-HbmWTHay9psM8qyzEKPc8odH4DsOuzdejtnr+OFtDmOcIVnhgReQ4GZBH7uwcjf6" crossorigin="anonymous">
<script src="<?= base_url() ?>asset/time/jquery.skedTape.js"></script>
<script src="<?= base_url('asset/'); ?>/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?= base_url('asset/'); ?>/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<script src="<?= base_url('asset/'); ?>/plugins/select2/js/select2.full.min.js"></script>
<script src="<?= base_url('asset/'); ?>/plugins/moment/moment.min.js"></script>
<script src="<?= base_url('asset/'); ?>/plugins/daterangepicker/daterangepicker.js"></script>

<script>

$(function () {
             $('.select').select2()

             $('.select2bs4').select2({
              theme: 'bootstrap4'
            })
           });

	$(document).ready(function(){
		  
  });


</script>




	<?php $this->load->view('tema/Footer'); ?>

