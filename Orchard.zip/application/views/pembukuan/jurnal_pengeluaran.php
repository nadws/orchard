<?php $this->load->view('tema/Header', $title); ?>

<script src="<?= base_url('css_maruti/'); ?>js/jquery.min.js"></script> 
<script src="<?php echo base_url('css_maruti/'); ?>assets/ajax.js"></script>

<style type="text/css">

.modal .modal-dialog-aside{
	width: 350px;
	max-width:80%; height: 500px; margin:0;
	transform: translate(0); transition: transform .2s;
}


.modal .modal-dialog-aside .modal-content{  height: inherit; border:0; border-radius: 0;}
.modal .modal-dialog-aside .modal-content .modal-body{ overflow-y: auto }
.modal.fixed-left .modal-dialog-aside{ margin-left:auto;  transform: translateX(100%); }
.modal.fixed-right .modal-dialog-aside{ margin-right:auto; transform: translateX(-100%); }

.modal.show .modal-dialog-aside{ transform: translateX(0);  }

.th{            
            top: 93px;            
        }

.acc{
  top: 60px;
}        

</style>

<!-- ======================================================== conten ======================================================= -->
<!-- Content Wrapper. Contains page content -->
<!-- <div class="content-wrapper"> -->
	
	<div class="content-header">
		<div class="container">

			<div class="row mb-2">
				<!-- <div class="col-sm-12">
					<h1 class="m-0 text-dark">Jurnal</h1>
				</div> -->
				<div class="col-sm-6">
					<?php if ($this->session->userdata('edit_hapus')=='1'): ?>
						<!-- <button data-toggle="modal" data-target="#modal-detail" class="btn btn-success"><i class="fas fa-download"></i> Detail</button> -->
						<!--<button data-toggle="modal" data-target="#modal-view" class="btn btn-success"><i class="fas fa-eye"></i> View</button>-->
						<!--<button data-toggle="modal" data-target="#modal-summary" class="btn btn-success"><i class="fas fa-print"></i> Summary</button>-->
						<!-- <button data-toggle="modal" data-target="#modal-delete" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button> -->
					<?php endif ?>
				</div>
				<!-- <div class="col-5 mt-2">
					<a href="<?= base_url('match/order'); ?>" class="btn btn-warning">Kembali</a>
				</div> -->
			</div>
		</div>
		<div class="row justify-content-center">
			<div class="col-md-12">
				
			</div>
			<div class="col-12">
      <?= $this->session->flashdata('message'); ?>
				<div class="card">
                    <div class="card-header">
                       <h3>Jurnal Pengeluaran</h3>
                       <button type="button" class="btn btn-sm btn-info" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus"></i> Tambah Data</button>
                    </div>
                        <?php $i=1; ?>
                        
                    <div class="card-body">
                   
                        <table class="table mt-2" id="example1">
                            <thead>
                                <tr>
									<th>#</th>
                                    <th >Tanggal</th>
                                    <th >Keterangan</th>
                                    <th >No Akun</th>
                                    <th >No Nota</th>
                                    <th >Nama Akun</th>                                    
                                    <th >Debit</th>
                                    <th >Kredit</th>
                                    <!-- <th>Aksi</th> -->
                                </tr>
                            </thead>
                            <tbody>                            
                            <?php foreach($jurnal as $p) : ?>
                            <tr>
                                <td><?= $i++ ?></td>
									<td><?= date('d-m-y' , strtotime($p->tgl)) ?></td>
                                    <td><?= $p->ket ?></td>
                                    <td><?= $p->no_akun ?></td>
                                    <td><?= $p->no_nota ?></td>
                                    <td><?= $p->nm_akun ?></td>                                    
                                    <td><?= number_format($p->debit,0) ?></td>
                                    <td><?= number_format($p->kredit,0) ?></td>
                                    <!-- <td>
										<button type="button" class="btn btn-sm btn-info" data-toggle="modal" data-target="#edit<?= $p->id_jurnal ?>"><i class="fa fa-edit"></i></button>
										<a href="<?= base_url() ?>match/drop_jurnal/<?= $p->id_jurnal ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah anda yakin ?')"><i class="fa fa-trash"></i></a>
									</td>                                     -->
                                </tr>
                            <?php endforeach; ?>    
                            </tbody>
                        </table>        
					</div>        
                                    

                    </div>
					
				</div>					
			</div>
			
			
		</div>
	</div>

    <style>
        .modal-lg {
          max-width: 900px;
          margin: 2rem auto;
        }
  </style>

<!-- Modal -->
<form action="" method="POST" id="form-jurnal">
<div class="modal fade" id="exampleModal" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background: #FFA07A;">
        <h5 class="modal-title" id="exampleModalLabel">Jurnal Pengeluaran</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

    <div class="row">

      <div class="col-sm-3 col-md-3">
              <div class="form-group">
                  <label for="list_kategori">Tanggal</label>
                  <input class="form-control" type="date" name="tgl" id="tgl" value="<?= date('Y-m-d') ?>" required>
                                  
              </div>                            
          </div>

          <div class="mt-3 ml-1">
            <p class="mt-4 ml-2 text-warning"><strong>Db</strong></p>                           
          </div>

              
              <div class="col-sm-4 col-md-4">
                  <div class="form-group">
                      <label for="list_kategori">Akun</label>
                      <select name="id_akun" id="id_akun" class="form-control select" required="">
                          <?php foreach($akun as $a): ?>    
                          <option value="<?= $a->id_akun ?>"><?= $a->nm_akun ?></option>
                          <?php endforeach ?>                    
                      </select>
                  </div>
              </div>
              
          <div class="col-sm-2 col-md-2">
              <div class="form-group">
                  <label for="list_kategori">Debit</label>
                  <input type="number" class="form-control total" id="total" name="total" readonly>                                        
              </div>                            
          </div>
          <div class="col-sm-2 col-md-2">
              <div class="form-group">
                  <label for="list_kategori">Kredit</label>
                  <input type="number" class="form-control" readonly>                                        
              </div>                            
          </div>

          <div class="col-sm-3 col-md-3">
                                
          </div>

          <div class="mt-1">
            <p class="mt-1 ml-3 text-warning"><strong>Cr</strong></p>                           
          </div>

          <div class="col-sm-4 col-md-4">
              <div class="form-group">
                      <select name="metode" id="metode" class="form-control select" required>
                        <?php foreach($kas as $k): ?>
                        <option value="<?= $k->id_akun ?>"><?= $k->nm_akun ?></option>
                        <?php endforeach; ?>                 
                      </select>
                  </div>                  
          </div>

          <div class="col-sm-2 col-md-2">
              <div class="form-group">
                  
                  <input type="number" class="form-control" readonly>                                        
              </div>                            
          </div>
          <div class="col-sm-2 col-md-2">
              <div class="form-group">
                
                  <input type="number" class="form-control total" readonly>                                        
              </div>                            
          </div>

               

             

     </div>

<!-- bkin ///////////-->
    <div id="bkin" class="detail">
    <hr>

        
    <div class="row">
          <div class="col-md-3">
                    <div class="form-group">
                        <label for="list_kategori">Produk</label>
                        <select name="id_produk[]" class="form-control select id_produk input_detail input_bkin" detail="1" required>
                                <option>-- Pilih Produk --</option>
                               <?php foreach($produk as $p): ?>
                               <option value="<?= $p->id_produk ?>"><?= $p->nm_produk ?></option>
                               <?php endforeach; ?>                 
                        </select> 
                                        
                    </div>                            
                </div>
    
                    
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="list_kategori">SKU</label>
                        <input type="text" class="form-control input_detail input_bkin" id="sku1" name="sku[]"  readonly>                                        
                    </div>                            
                </div>
                <div class="col-md-1">
                    <div class="form-group">
                        <label for="list_kategori">Satuan</label>
                        <input type="text" class="form-control input_detail input_bkin" id="satuan1" name="satuan[]" readonly>                                        
                    </div>                            
                </div>

                <div class="col-md-1">
                    <div class="form-group">
                        <label for="list_kategori">Qty</label>
                        <input type="text" class="form-control qty1 input_detail input_bkin" qty="1" name="qty[]" required>                                        
                    </div>                            
                </div>

                <div class="col-md-2">
                    <div class="form-group">
                        <label for="list_kategori">Rp/Satuan</label>
                        <input type="text" class="form-control rp_beli input_detail input_bkin" rp_beli="1" name="rp_beli[]" required>                                        
                    </div>                            
                </div>

                <div class="col-md-2">
                    <div class="form-group">
                        <label for="list_kategori">Rp/Pajak</label>
                        <input type="text" class="form-control rp_pajak rp_pajak1 input_detail input_bkin" rp_pajak="1" name="rp_pajak[]" required>                                        
                    </div>                            
                </div>

            </div>
            <div id="detail_bkin">
            
            </div>  

            <div align="right" class="mt-2">
            <button type="button" id="tambah_bkin" class="btn-sm btn-success">Tambah</button>
            </div>

    </div>

    <!-- monitoring ///////////-->

    <div id="monitoring" class="detail">
    <hr>  
        
    <div class="row">

        <div class="col-md-3">
                    <div class="form-group">
                        <label for="list_kategori">Keterangan</label>
                        <input type="text" class="form-control input_detail input_monitoring" name="ket[]" required>                                        
                    </div>                            
        </div>                        

          <div class="col-md-2">
                    <div class="form-group">
                        <label for="list_kategori">Satuan</label>
                        <select name="id_satuan[]" class="form-control select satuan input_detail input_monitoring" required>
                               <?php foreach($satuan as $p): ?>
                               <option value="<?= $p->id_satuan ?>"><?= $p->satuan ?></option>
                               <?php endforeach; ?>                 
                        </select> 
                                        
                    </div>                            
                </div>

                <div class="col-md-2">
                    <div class="form-group">
                        <label for="list_kategori">Qty</label>
                        <input type="text" class="form-control input_detail input_monitoring qty_monitoring1" qty=1 name="qty[]"  required>                                        
                    </div>                            
                </div>

                <div class="col-md-2">
                    <div class="form-group">
                        <label for="list_kategori">Rp/Satuan</label>
                        <input type="text" class="form-control input_detail input_monitoring rp_satuan" name="rp_beli[]" rp_satuan='1' required>                                        
                    </div>                            
                </div>

                <div class="col-md-2">
                    <div class="form-group">
                        <label for="list_kategori">Total Rp</label>
                        <input type="text" class="form-control  input_detail input_monitoring total_rp total_rp1" name="ttl_rp[]" required>                                        
                    </div>                            
                </div>

            </div>

            <div id="detail_monitoring">
            
            </div> 

            <div align="right" class="mt-2">
            <button type="button" id="tambah_monitoring" class="btn-sm btn-success">Tambah</button>
            </div>

    </div> 

    <!-- non-monitoring -->

    <div id="non_monitoring" class="detail">
    <hr>  
        
    <div class="row">

        <div class="col-md-4">
                    <div class="form-group">
                        <label for="list_kategori">Keterangan</label>
                        <input type="text" class="form-control input_detail input_non_monitoring" name="ket[]" required>                                        
                    </div>                            
        </div>                        

                <div class="col-md-3">
                    <div class="form-group">
                        <label for="list_kategori">Total Rp</label>
                        <input type="text" class="form-control  input_detail input_non_monitoring total_rp" name="ttl_rp[]" required>                                        
                    </div>                            
                </div>

            </div>

            <div id="detail_non_monitoring">
            
            
            </div>

            <div align="right" class="mt-2">
            <button type="button" id="tambah_non_monitoring" class="btn-sm btn-success">Tambah</button>
            </div>

    </div> 
                                 

      
                   

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Input</button>
      </div>
    </div>
  </div>
</div>
</form>






<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/solid.css" integrity="sha384-wnAC7ln+XN0UKdcPvJvtqIH3jOjs9pnKnq9qX68ImXvOGz2JuFoEiCjT8jyZQX2z" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/fontawesome.css" integrity="sha384-HbmWTHay9psM8qyzEKPc8odH4DsOuzdejtnr+OFtDmOcIVnhgReQ4GZBH7uwcjf6" crossorigin="anonymous">
<script src="<?= base_url() ?>asset/time/jquery.skedTape.js"></script>
<script src="<?= base_url('asset/'); ?>/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?= base_url('asset/'); ?>/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<script src="<?= base_url('asset/'); ?>/plugins/select2/js/select2.full.min.js"></script>
<script src="<?= base_url('asset/'); ?>/plugins/moment/moment.min.js"></script>
<script src="<?= base_url('asset/'); ?>/plugins/daterangepicker/daterangepicker.js"></script>

<script>

$(function () {
             $('.select').select2()

             $('.select2bs4').select2({
              theme: 'bootstrap4'
            })
           });


$(document).ready(function(){

// function kodeOtomatis(akun,id_akun){
//   var tgl = $('#tgl').val();
//   var tgl1    = tgl.split("-");
//   var bulan   = tgl1[1];
//   var tahun   = tgl1[0];
//   var tahun2  = tahun.substring(2, 4)
//   var kode    = akun+bulan+tahun2;

//   $.ajax({
//                 url:"<?= base_url(); ?>Match/kode/",
//                 method:"POST",
//                 data:{id_akun:id_akun, tgl:tgl},
//                 success:function(data){
//                 $('#no_nota').val(kode+data);
                                  
//                 }

//               });


// }
hide_default();

function hide_default() {
  $('.detail').hide();
  $('.input_detail').attr('disabled','true');
}

  

$('#id_akun').change(function(){
            var id_akun = $(this).val();
            
            var monitoring = ['10','11','12','18'];

            if(id_akun == 27){
              hide_default();
              $('#bkin').show();
        	    $('.input_bkin').removeAttr('disabled','true');
              $("#form-jurnal").attr("action", "<?=base_url()?>Match/add_bkin");
            }else if(monitoring.includes(id_akun)){
              hide_default();
              $('#monitoring').show();
        	    $('.input_monitoring').removeAttr('disabled','true');
              $("#form-jurnal").attr("action", "<?=base_url()?>Match/add_pengeluaran");
            }else{
              hide_default();
              $('#non_monitoring').show();
        	    $('.input_non_monitoring').removeAttr('disabled','true');
              $("#form-jurnal").attr("action", "<?=base_url()?>Match/add_pengeluaran");
            }
            
		        });


// $("body").on( "keyup", ".debit_edit", function(){

          
// var debit_edit = 0;

//     $(".debit_edit").each(function(){
//     debit_edit += parseInt($(this).val());
//   });
//   $('.total_edit').val(debit_edit);

// });

$("body").on( "change", ".id_produk", function(){
// $('.id_produk').change(function(){
   var id_produk = $(this).val();
   var detail = $(this).attr('detail');

   $.ajax({
                url:"<?= base_url(); ?>match/get_data_produk/",
                method:"POST",
                data:{id_produk:id_produk},
                dataType:"json",
                success:function(data){
                  
                  // alert(data.biaya);
                //   $('#cancel').modal('show');
                  
                  $('#sku'+detail).val(data.sku);
                  $('#satuan'+detail).val(data.satuan);                  
                }

              });
  
  


});

//////////////////////BKIN/////////////////////////////
$("body").on( "keyup", ".rp_beli", function(){
        // $('.rp_beli').keyup(function(){
            var rp_beli = parseInt($(this).val());
			var detail = $(this).attr('rp_beli');
            
            var qty = parseInt($('.qty'+detail).val());

            var ttl_harga = rp_beli * qty;
            var rp_pajak = ttl_harga * 10 / 100;
            var total = ttl_harga + rp_pajak;
            // console.log(total);
            $('.rp_pajak'+detail).val(total);

            var debit = 0;
        
            $(".rp_pajak:not([disabled=disabled]").each(function(){
            debit += parseInt($(this).val());
          });
          $('.total').val(debit);
          });
//////////
    $("body").on( "keyup", ".rp_pajak", function(){
        //   $('.rp_pajak').keyup(function(){
            var debit = 0;
        
            $(".rp_pajak:not([disabled=disabled]").each(function(){
            debit += parseInt($(this).val());
          });
          $('.total').val(debit);
          });

    var count_bkin = 1;
        $('#tambah_bkin').click(function(){
        count_bkin = count_bkin + 1;
        // var no_nota_atk = $("#no_nota_atk").val();
        var html_code = "<div class='row' id='row"+count_bkin+"'>";

        html_code += '  <div class="col-md-3"><div class="form-group"><select name="id_produk[]" class="form-control select id_produk input_detail input_bkin" detail="'+count_bkin+'" required><option>-- Pilih Produk --</option><?php foreach($produk as $p): ?><option value="<?= $p->id_produk ?>"><?= $p->nm_produk ?></option><?php endforeach; ?></select></div></div>';

        html_code += '<div class="col-md-2"><div class="form-group"><input type="text" class="form-control input_detail input_bkin" id="sku'+count_bkin+'" name="sku[]" readonly></div></div>';

        html_code += '<div class="col-md-1"><div class="form-group"><input type="text" class="form-control input_detail input_bkin" id="satuan'+count_bkin+'" name="satuan[]" readonly></div></div>';

        html_code += '<div class="col-md-1"><div class="form-group"><input type="text" class="form-control qty'+count_bkin+' input_detail input_bkin" qty="'+count_bkin+'" name="qty[]" required></div></div>';

        html_code += '<div class="col-md-2"><div class="form-group"><input type="text" class="form-control rp_beli input_detail input_bkin" rp_beli="'+count_bkin+'" name="rp_beli[]" required></div></div>';

        html_code += ' <div class="col-md-2"><div class="form-group"><input type="text" class="form-control rp_pajak rp_pajak'+count_bkin+' input_detail input_bkin" rp_pajak="'+count_bkin+'" name="rp_pajak[]" required></div></div>';

        html_code += ' <div class="col-md-1"><button type="button" name="remove" data-row="row'+count_bkin+'" class="btn btn-danger btn-sm remove">-</button></div>';  
        

        html_code += "</div>";

        $('#detail_bkin').append(html_code);
        $('.select').select2()
        });

        $(document).on('click', '.remove', function(){
        var delete_row = $(this).data("row");
        $('#' + delete_row).remove();
      });


//////////////////////Monitoring/////////////////////////////
$("body").on( "keyup", ".rp_satuan", function(){
        // $('.rp_beli').keyup(function(){
            var rp_beli = parseInt($(this).val());
			var detail = $(this).attr('rp_satuan');
            
            var qty = parseInt($('.qty_monitoring'+detail).val());

            var ttl_harga = rp_beli * qty;
            
            
            $('.total_rp'+detail).val(ttl_harga);

            var debit = 0;
        
            $(".total_rp:not([disabled=disabled]").each(function(){
            debit += parseInt($(this).val());
          });
          $('.total').val(debit);
          });
//////////
    $("body").on( "keyup", ".total_rp", function(){
        //   $('.rp_pajak').keyup(function(){
            var debit = 0;
        
            $(".total_rp:not([disabled=disabled]").each(function(){
            debit += parseInt($(this).val());
          });
          $('.total').val(debit);
          });


// Monitoring
        var count_monitoring = 1;
        $('#tambah_monitoring').click(function(){
        count_monitoring = count_monitoring + 1;
        // var no_nota_atk = $("#no_nota_atk").val();
        var html_code = "<div class='row' id='row_monitoring"+count_monitoring+"'>";

        html_code += '<div class="col-md-3"><div class="form-group"><input type="text" class="form-control input_detail input_monitoring" name="ket[]" required></div></div>';

        html_code += '<div class="col-md-2"><div class="form-group"><select name="id_satuan[]" class="form-control select satuan input_detail input_monitoring" required><?php foreach($satuan as $p): ?><option value="<?= $p->id_satuan ?>"><?= $p->satuan ?></option><?php endforeach; ?></select></div></div>';

        html_code += '<div class="col-md-2"><div class="form-group"><input type="text" class="form-control input_detail input_monitoring qty_monitoring'+count_monitoring+'" qty="'+count_monitoring+'" name="qty[]" required></div></div>';

        html_code += '<div class="col-md-2"><div class="form-group"><input type="text" class="form-control input_detail input_monitoring rp_satuan" name="rp_beli[]" rp_satuan="'+count_monitoring+'" required></div></div>';

        html_code += '<div class="col-md-2"><div class="form-group"><input type="text" class="form-control  input_detail input_monitoring total_rp total_rp'+count_monitoring+'" name="ttl_rp[]" required></div></div>';

        html_code += ' <div class="col-md-1"><button type="button" name="remove" data-row="row_monitoring'+count_monitoring+'" class="btn btn-danger btn-sm remove_monitoring">-</button></div>';  
        

        html_code += "</div>";

        $('#detail_monitoring').append(html_code);
        $('.select').select2()
        });

      $(document).on('click', '.remove_monitoring', function(){
        var delete_row = $(this).data("row");
        $('#' + delete_row).remove();
      });


      //////////////////////Non Monitoring/////////////////////////////

    $("body").on( "keyup", ".total_rp", function(){
        //   $('.rp_pajak').keyup(function(){
            var debit = 0;
        
            $(".total_rp:not([disabled=disabled]").each(function(){
            debit += parseInt($(this).val());
          });
          $('.total').val(debit);
          });


// Non Monitoring
        var count_non_monitoring = 1;
        $('#tambah_non_monitoring').click(function(){
        count_non_monitoring = count_non_monitoring + 1;
        // var no_nota_atk = $("#no_nota_atk").val();
        var html_code = "<div class='row' id='row_non_monitoring"+count_non_monitoring+"'>";

        html_code += '<div class="col-md-4"><div class="form-group"><input type="text" class="form-control input_detail input_non_monitoring" name="ket[]" required></div></div>';

        html_code += '<div class="col-md-3"><div class="form-group"><input type="text" class="form-control  input_detail input_non_monitoring total_rp" name="ttl_rp[]" required></div></div>';

        html_code += ' <div class="col-md-1"><button type="button" name="remove" data-row="row_non_monitoring'+count_non_monitoring+'" class="btn btn-danger btn-sm remove_non_monitoring">-</button></div>';  
        

        html_code += "</div>";

        $('#detail_non_monitoring').append(html_code);
        // $('.select').select2()
        });

      $(document).on('click', '.remove_non_monitoring', function(){
        var delete_row = $(this).data("row");
        $('#' + delete_row).remove();
      });


    });


</script>


	<script>
		function autofill_anak(){
			var nm_kry = document.getElementById('nm_kry').value;
			$.ajax({
				url:"<?php echo base_url();?>Match/cari_anak",
				data:'&nm_kry='+nm_kry,
				success:function(data){
					var hasil = JSON.parse(data);  

					$.each(hasil, function(key,val){ 
						document.getElementById('id_kry').value=val.id_kry;
						document.getElementById('nm_kry').value=val.nm_kry;  
					});
				}
			});                   
		}

	</script>

	<?php $this->load->view('tema/Footer'); ?>

