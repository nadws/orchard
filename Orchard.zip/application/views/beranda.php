<?php $this->load->view('tema/Header', $title); ?>

<!-- ======================================================== conten ======================================================= -->
<!-- Content Wrapper. Contains page content -->
<!-- <div class="content-wrapper"> -->
	<div class="content-header">
		<div class="row">
			<div class="card-header">
				<div class="col-12" >
					<img src="<?= base_url('asset/image0.png'); ?>" style="margin-left: 170px;" width="1000" height="400">
				</div>
			</div>
		</div>
	</div>

	<!-- ======================================================== conten ======================================================= -->
	
	<!-- ======================================================== conten ======================================================= -->



	<?php $this->load->view('tema/Footer'); ?>