<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

  <style>
  .invoice
  {
    margin: auto;
    width: 70mm;
    background: #FFF;
  }
  .huruf {
	  font-size: 14px;
  }
</style>
<script>
  window.print();
</script>

  <title>Document</title>
</head>
<body>
  

  



<div class="invoice">
	<br>
  <center>
   <img width="150" src="<?= base_url('asset/');  ?>orchard_small.png" alt="">
 </center>
 <p align="center" class="huruf">Orchard Beauty Studio</p>
 <p align="center" style="margin-top: -10px;" class="huruf">Orchard Nail</p>
 <p style=" margin-top: -10px;" align="center" class="huruf">081151-88778</p>
 <p style=" margin-top: -10px;" align="center" class="huruf">Jalan KS Tubun 28 B-D RT 20 RW 02 Kelurahan Kelayan</p>
 <p style=" margin-top: -10px;" align="center" class="huruf">Kota Banjarmasin</p>
 

 <table width="100%">
  <tr>
  	<td width="40%" class="huruf">No Nota</td>
	<td style="text-align: left; " class="huruf">: <?= $invoice->no_nota; ?></td>
  </tr>
  <tr>
  	<td width="40%" class="huruf">Waktu</td>
	<td style="text-align: left; " class="huruf">: <?= date('d M Y h:i', strtotime($invoice->tgl_jam)) ?></td>
  </tr>
  <tr>
  	<td width="40%" class="huruf">Order</td>
	<td style="text-align: left; " class="huruf">: Kasir Orchard</td>
  </tr>
  <tr>
  	<td width="40%" class="huruf">Kasir</td>
	<td style="text-align: left; " class="huruf">: Kasir Orchard</td>
  </tr>
  <?php if($invoice->id_customer != 0): ?>
  <?php $nm_cutomer = strtolower($invoice->nama) ?>
  <tr>
  	<td width="40%" class="huruf">Customer</td>
	<td style="text-align: left; " class="huruf">: <?= ucwords($nm_cutomer); ?></td>
  </tr>
  <?php endif; ?>
   <!-- <tr>
     <td>
      #<?= substr($pesan_2->no_order, 5); ?><br><br>  
      <?= $this->session->userdata('nm_resto'); ?>
    </td>
    <td align="center">
     PAX : <?= $pesan_2->page; ?>
   </td>
   <td>
     <td style="text-align: right;">TABLE <?= $pesan_2->no_meja; ?></td>
   </td>
 </tr> -->
</table>

<hr>
  <table width="100%">
	  <?php 
	  $total_produk = 0;
	  $qty_produk = 0; 
	  ?>
  <?php if(!empty($produk)): ?>
		<?php foreach($produk as $p): ?>
		<?php
		 $total_produk += $p->jumlah * $p->harga;
		 $qty_produk += $p->jumlah;
     $nm_produk = strtolower($p->nm_produk);
     $hrg_produk = $p->jumlah * $p->harga;
     $hrg_asli = $p->jumlah * $p->harga_asli;
		?>
	  <tr class="huruf" style="margin-bottom: 2px;">
		  <td  width="10%"><?= $p->jumlah; ?></td>
      <td width="50%"><?= ucwords($nm_produk); ?></td>
      
      <td width="40%" style="text-align: right;">
      <?php if($hrg_asli != $hrg_produk): ?>
      <!-- <small ><?= $p->diskon ?>%</small> -->
       <strike><?= number_format($hrg_asli,0); ?></strike><br>
      <?= number_format($hrg_produk,0); ?>
    
      <?php else: ?>
        <?= number_format($hrg_produk,0); ?>
      <?php endif; ?>
      </td>  
	  </tr>
	  <?php endforeach; ?>
	  <?php endif; ?>
	  <?php 
	  $total_servis = 0;
	  $qty_servis = 0; 
	  ?>
	  <?php if(!empty($servis)): ?>
		<?php foreach($servis as $s): ?>
			<?php 
				$total_servis +=  $s->qty * $s->biaya;
				$qty_servis += $s->qty;
        $nm_servis = strtolower($s->nm_servis);
				?>
	  <tr class="huruf" style="margin-bottom: 2px;">
		  <td  width="10%"><?= $s->qty; ?></td>
		  <td width="50%"><?= ucwords($nm_servis); ?></td>
		  <td width="40%" style="text-align: right;"><?= number_format($s->qty * $s->biaya,0); ?></td>
	  </tr>
	  <?php endforeach; ?>
	  <?php endif; ?>
  </table>
  <hr>
  <table width="100%">
	  <?php if($qty_produk != 0): ?>
	  <tr class="huruf">
		  <td>Subtotal <?= $qty_produk; ?> Product</td>
		  <td style="text-align: right;"><?= number_format($total_produk,0) ?></td>
	  </tr>
	  <?php endif; ?>
	  <?php if($qty_servis != 0): ?>
	  <tr class="huruf">
		  <td>Subtotal <?= $qty_servis; ?> Service</td>
		  <td style="text-align: right;"><?= number_format($total_servis,0) ?></td>
	  </tr>
	  <?php endif; ?>
	  <tr class="huruf">
		  <td><strong>Total Tagihan</strong></td>
		  <td style="text-align: right;"><strong><?= number_format($total_servis + $total_produk,0); ?></strong></td>
	  </tr>
  </table>
  <hr>
  <table width="100%">
  <?php if($invoice->diskon !=0): ?>
	  <tr class="huruf">
		  <td>Diskon</td>
		  <td style="text-align: right;"><?= number_format($invoice->diskon,0); ?></td>
	  </tr>
    <?php endif; ?>
    
    <?php if($invoice->dp !=0): ?>
	  <tr class="huruf">
		  <td>Kredit BCA</td>
		  <td style="text-align: right;"><?= number_format($invoice->dp,0); ?></td>
	  </tr>
	  <?php endif; ?>
      
	  <?php if($invoice->bca_kredit !=0): ?>
	  <tr class="huruf">
		  <td>Kredit BCA</td>
		  <td style="text-align: right;"><?= number_format($invoice->bca_kredit,0); ?></td>
	  </tr>
	  <?php endif; ?>
	  <?php if($invoice->bca_debit !=0): ?>
	  <tr class="huruf">
		  <td>Debit BCA</td>
		  <td style="text-align: right;"><?= number_format($invoice->bca_debit,0); ?></td>
	  </tr>
	  <?php endif; ?>
	  <?php if($invoice->mandiri_kredit !=0): ?>
	  <tr class="huruf">
		  <td>Kredit Mandiri</td>
		  <td style="text-align: right;"><?= number_format($invoice->mandiri_kredit,0); ?></td>
	  </tr>
	  <?php endif; ?>
	  <?php if($invoice->mandiri_debit !=0): ?>
	  <tr class="huruf">
		  <td>Debit Mandiri</td>
		  <td style="text-align: right;"><?= number_format($invoice->mandiri_debit,0); ?></td>
	  </tr>
	  <?php endif; ?>
	  <?php if($invoice->cash !=0) : ?>
	  <tr class="huruf">
		  <td>Cash</td>
		  <td style="text-align: right;"><?= number_format($invoice->cash,0) ; ?></td>
	  </tr>
	  <?php endif; ?>
	  <tr class="huruf">
		  <td><strong>Total Pembayaran</strong></td>
		  <td style="text-align: right;"><strong><?= number_format($invoice->bayar,0); ?></strong></td>
	  </tr>
	  <tr class="huruf">
		  <td>Kembalian</td>
		  <td style="text-align: right;"><?= number_format($invoice->bayar - $invoice->total,0); ?></td>
	  </tr>
  </table>
  <hr>
  <hr>
  <p class="huruf" align="center">Thank You For Next Appointment !</p>
  <p class="huruf" align="center" style="margin-top: -10px;">Call 081151-88778</p>
  <p class="huruf" align="center">Instagram : orchard.nail</p>
  <p class="huruf" align="center">Terbayar</p>
  <p class="huruf" align="center" style="margin-top: -10px;"><-------- <?= date('d M Y h:i'); ?> --------></p>
  
<!-- <table width="100%">
 <?php foreach ($pesan  as $d): ?>
  <tr>
    <td style="text-align: left;" width="6%"><?= $d->qty; ?></td>
    <td style="font-size: 15px;">
      <?= $d->nm_menu; ?>
    </td>
    <td  width="22%">
      <?= number_format($d->harga * $d->qty); ?>
    </td>

    <td width="15%" align="right">
      <?= $d->selisih ." / ". $d->selisih2; ?>
    </td>
  </tr>
<?php endforeach ?>
</table> -->
<!-- <table width="100%">
  <tr>
    <td style="text-align: left;" width="6%"></td>
    <td style="font-size: 14px;"></td>
    <td  style="font-weight: bold;" width="22%"></td>
    <td width="15%" align="right"></td>
  </tr>
  <tr>
    <td style="text-align: left;" width="6%"></td>
    <td style="font-size: 14px;">
     SUBTOTAL
   </td>
   <td>
    <?= number_format($saksi->bayar); ?>
  </td>

  <td width="15%" align="right">

  </td>
</tr>
<tr>
  <td style="text-align: left;" width="6%"></td>
  <td style="font-size: 14px;">
   DISCOUNT
 </td>
 <td width="22%">
   <?= number_format($saksi->diskon); ?>
 </td>

 <td width="15%" align="right">

 </td>
</tr>
<tr>
  <td style="text-align: left;" width="6%"></td>
  <td style="font-size: 14px;">
   SERVICE CHARGE
 </td>
 <td width="22%">
  <?= number_format($saksi->service); ?>
</td>

<td width="15%" align="right">

</td>
</tr>
<tr>
  <td style="text-align: left;" width="6%"></td>
  <td style="font-size: 14px;">
   TAX
 </td>
 <td width="22%">
  <?= number_format($saksi->tax); ?>
</td>

<td width="15%" align="right">

</td>
</tr>
<tr>
  <td style="text-align: left;" width="6%"></td>
  <td style="font-size: 14px; font-weight: bold;">
   TOTAL TAGIHAN
 </td>
 <td  style="font-weight: bold;" width="22%">
   <?= number_format($c); ?>
 </td>

 <td width="15%" align="right">

 </td>
</tr>
<tr>
  <td style="text-align: left;" width="6%"></td>
  <td style="font-size: 14px;">
    <?php if (empty($payment->cash)): ?>
      <?php else: ?>
        CASH <div style="margin-top: 5px;"></div>
      <?php endif ?>
      <?php if (empty($payment->dbca)): ?>
        <?php else: ?>
         DEBIT BCA <div style="margin-top: 5px;"></div>
       <?php endif ?>
       <?php if (empty($payment->kbca)): ?>
        <?php else: ?>
         KREDIT BCA <div style="margin-top: 5px;"></div>
       <?php endif ?>
       <?php if (empty($payment->dman)): ?>
        <?php else: ?>
         DEBIT MANDIRI <div style="margin-top: 5px;"></div>
       <?php endif ?>
       <?php if (empty($payment->kman)): ?>
        <?php else: ?>
         KREDIT MANDIRI <div style="margin-top: 5px;"></div>
       <?php endif ?>
     </td>
     <td width="22%">
       <?php if (empty($payment->cash)): ?>
        <?php else: ?>
          <?= number_format($payment->cash) ?> <div style="margin-top: 5px;"></div>
        <?php endif ?>
        <?php if (empty($payment->dbca)): ?>
          <?php else: ?>
           <?= number_format($payment->dbca) ?> <div style="margin-top: 5px;"></div>
         <?php endif ?>
         <?php if (empty($payment->kbca)): ?>
          <?php else: ?>
           <?= number_format($payment->kbca) ?><div style="margin-top: 5px;"></div>
         <?php endif ?>
         <?php if (empty($payment->dman)): ?>
          <?php else: ?>
            <?= number_format($payment->dman) ?> <div style="margin-top: 5px;"></div>
          <?php endif ?>
          <?php if (empty($payment->kman)): ?>
            <?php else: ?>
             <?= number_format($payment->kman) ?> <div style="margin-top: 5px;"></div>
           <?php endif ?>
         </td>
         <td width="15%" align="right">

         </td>
       </tr>
       <tr>
        <td style="text-align: left;" width="6%"></td>
        <td style="font-size: 14px; font-weight: bold;">
          TOTAL PEMBAYARAN
       </td>
       <td  style="font-weight: bold;" width="22%">
         <?= number_format($payment->total); ?>
       </td>

       <td width="15%" align="right">

       </td>
     </tr>
     <tr>
      <td style="text-align: left;" width="6%"></td>
      <td style="font-size: 14px;">
        CHANGE
      </td>
      <td width="22%">
        <?= number_format($saksi->dibayar - $c); ?>
      </td>

      <td width="15%" align="right">

      </td>
    </tr>
  </table> -->
  <!-- <p align="center">
    <?= $Weddingdate->format("h:i a");?><br><br>
    Closed <?php 
    date_default_timezone_set('Asia/Makassar');
    echo date("M j, Y h:i a"); ?>
  </p> -->
  <!-- <hr>
  <p align="center"> **  Thank you ! see you next time !   **</p>
</div> -->
<!-- ======================================================== conten ======================================================= -->

<!-- ======================================================== conten ======================================================= -->

<!-- <script src="<?= base_url('live_edit/jquery.min.js') ?>"></script> -->
<script>
  var url = document.getElementById('url').value;
    var count = 5; // dalam detik
    function countDown() {
      if (count > 0) {
        count--;
        var waktu = count + 1;
        $('#pesan').html('Anda akan di redirect ke ' + url + ' dalam ' + waktu + ' detik.');
        setTimeout("countDown()", 1000);
      } else {
        window.location.href = url;
      }
    }
    countDown();
  </script> 

</body>
</html>